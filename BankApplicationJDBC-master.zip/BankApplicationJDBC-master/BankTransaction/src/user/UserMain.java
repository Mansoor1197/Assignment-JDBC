package user;

import java.util.Scanner;
import bean.Account;
import bean.Loan;
import bean.Transaction;
import dao.IDao;
import dao.DaoImp;
import exception.AccountIDException;
import exception.AccountNameException;
import service.IService;
import service.ServiceImp;

public class UserMain {

	public static void main(String[] args) {
		Account[] accs = new Account[10];
		Loan[] l = new Loan[10];
		IService service = new ServiceImp();
		Transaction t = new Transaction();
		IDao dao=new DaoImp();
		Scanner scanner = new Scanner(System.in);
		String AccountId, AccountName, loanType,LoanAccountId;
		double loanAmount = 0.0,Totalamount=0.0;
		Integer amount;
		while (true) {
			System.out.println("Choose any one");
			System.out.println("Enter 1 for Create account");
			System.out.println("Enter 2 for Deposit");
			System.out.println("Enter 3 for Withdraw");
			System.out.println("Enter 4 for ShowAccountDetails");
			System.out.println("Enter 5 for GetLoan");
			System.out.println("Enter 6 for PayLoan");
			System.out.println("Enter 7 for ShowLoanDetails");
			System.out.println("Enter 8 Exit");
			int option = scanner.nextInt();
			switch (option) {
			case 1: {//Create account
				
				Account acc=new Account();
			
				System.out.println("enter your AccountId ex :[1234567-ABCD] ");

				while (true) {
					AccountId = scanner.next();
					if (service.accountIdValid(AccountId)) {
						acc.setAccountid(AccountId);
						break;
					} else
						throw new AccountIDException();
				}

				System.out.println("Enter AccountName : ");
				while (true) {
					AccountName = scanner.next();
					if (service.accountNameValid(AccountName)) {
						acc.setAccountname(AccountName);
						break;
					}else
						throw new AccountNameException();
				}

				System.out.println("Enter Address : ");
                                acc.setAddress(scanner.next());
                                System.out.println("Enter deposit Amount : ");
                                acc.setDepositAmount(scanner.nextDouble());
			accs[a]=acc;
			a++;
                            dao.createAccount(account);
                                for(Account res:accs) {
					if(res==null)
						break;
					System.out.println(res);
					
				}

				break;
			}
			case 2: {//Depositamount
				System.out.println("enter your AccountId ex :[1234567-ABCD] ");

				while (true) {
					AccountId = scanner.next();
					if (service.accountIdValid(AccountId)) {

							System.out.println("Enter deposit Amount : ");
							amount = scanner.nextInt();
								
							Totalamount=t.depositAmount(AccountId, amount);
							
							System.out.println("updated balance"+Totalamount);
								break;
							}
					 else {
							throw new AccountIDException();
					}

							
						}
						
					
				break;
			}
			
			
			case 3: {//Withdrawamount
				System.out.println("enter your AccountId ex :[1234567-ABCD] ");

				while (true) {
					AccountId = scanner.next();
					if (service.accountIdValid(AccountId)) {

								System.out.println("Enter withdraw Amount : ");
								amount = scanner.nextInt();
								Totalamount=t.withdrawAmount(AccountId, amount);
							
							System.out.println("updated balance"+Totalamount);
								break;
							}
					 else {
							throw new AccountIDException();
					}

							
						}
						
					
				break;
			}
			case 4: {//ShowAccountDetails
				System.out.println("enter your AccountId ex :[1234567-ABCD] ");

				while (true) {
					AccountId = scanner.next();
					if (service.accountIdValid(AccountId)) {
						t.showDetails(AccountId);
						break;
					} else
						throw new AccountIDException();
						
				}
				

				break;

			}
			case 5: {//Get Loan
				Loan loan=new Loan();
			        System.out.println("enter loanId: ");
				loanId = scanner.nextInt();
				loan.setLoanId(loanId);
				System.out.println("Enter LoanAmount : ");
				loanAmount = scanner.nextDouble();
				loan.setLoanAmount(loanAmount);
				System.out.println("Enter Loan Type: Home/ Car/ Education/ Bike");
			
					loanType = scanner.next();
					loan.setLoanType(loanType);
					System.out.println("Enter your accountID");
					LoanAccountId=scanner.next();
			                loan=t.getLoan(loan,LoanAccountId);
							
				break;
			}
			case 6: {//payloan
				System.out.println("enter loanId: ");
				loanId = scanner.nextInt();
						System.out.println("enter the amount you want to repay");
						loanAmount=scanner.nextDouble();
						System.out.println(t.payLoan(loanId,loanAmount));
				break;
			}
			
			case 7: {//showLoanDetails

				System.out.println("enter your Loanid ");
				loanId = scanner.nextInt();
						System.out.println(t.showLoanDetails(loanId));

					
			break;
				
	}
			case 8: {
				System.out.println("Thank you ..");
				break ;

			}
			default: {
				System.out.println("Please select valid option!");
				break;
			}
	}
	}
}
}
