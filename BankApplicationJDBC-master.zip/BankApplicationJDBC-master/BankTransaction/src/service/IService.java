package service;

public interface IService {

        public boolean accountIdValid(String id);
	public boolean accountNameValid(String name);

}
