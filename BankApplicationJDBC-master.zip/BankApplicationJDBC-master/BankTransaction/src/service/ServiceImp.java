package service;

import dao.IDao;
import dao.DaoImp;

public class ServiceImp implements IService {
	IDao dao = new DaoImp();
        @Override
	public boolean accountIdValid(String id) {
		String pattern = "^[0-9]{7}+[A-Za-z]{4}$";
		return id.matches(pattern);
	}
        @Override
	public boolean accountNameValid(String name) {
		String pattern = "^[A-Z]{1}+[a-z]{2,}$";
		return name.matches(pattern);

	}

}
