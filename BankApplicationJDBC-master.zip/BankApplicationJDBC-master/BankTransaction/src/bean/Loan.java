package bean;

import dao.IDao;
import dao.DaoImp;

public class Loan extends Account {
	IDao dao=new DaoImp();
	private Integer loanId;
	private Double loanAmount;
	private String loanType;
        public Loan() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Loan(Integer loanId, Double loanAmount, String loanType) {
		super();
		this.loanId = loanId;
                this.loanAmount = loanAmount;
		this.loanType = loanType;
		
	}

	public Integer getLoanId() {
		return loanId;
	}

	public void setLoanId(Integer loanId) {
		this.loanId = loanId;
	}

	public Double getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(Double loanAmount) {
		this.loanAmount = loanAmount;
	}

	public String getLoanType() {
		return loanType;
	}

	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public Loan getLoan(Loan loan,String accnum) {
		System.out.println("loan class");
		return(dao.getLoan(loan,accnum));
	}

	public Loan showLoanDetails(int loanid) {
		return(dao.showLoanDetails(loanid));
	}

	@Override
	public String toString() {
		return "Loan [loanId=" + loanId + ", loanAmount=" + loanAmount + ", loanType=" + loanType + "]";
	}
}
