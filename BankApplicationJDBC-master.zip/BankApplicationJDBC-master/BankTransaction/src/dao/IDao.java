package dao;

import bean.Account;
import bean.Loan;

public interface IDao {
        public void createAccount(Account account);
	public Account getDetails(String accountId);
        public Loan showLoanDetails(int loanid);
        public Double withdrawAmount(String accountid,Integer amount);
        public Loan payLoan(Integer loanid,Double loanamount);
        public Double depositAmount(String accountid,  Integer amount);
        public Loan getLoan(Loan loan, String accnum);
}
