package dao;
import java.sql.*;  
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import bean.Account;
import bean.Loan;
import dao.IDao;

public class DaoImp implements IDao {
	Connection con = null;
	PreparedStatement ps = null;
	Statement st = null;
	ResultSet rs = null;
	Integer res = null;

        @Override
	public void createAccount(Account account)  {
		
		String query="insert into account values(?,?,?,?)";
		
			try {
				Class.forName("com.mysql.jdbc.Driver");
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/bdb?user=root&password=man123");
				ps=con.prepareStatement(query);
				ps.setString(1, account.getAccountid());
				ps.setString(2, account.getAccountname());
				ps.setString(3, account.getAddress());
				ps.setDouble(4, account.getDepositAmount());
				int res=ps.executeUpdate();
				if(res >0) {
					System.out.println("account created successfully!");
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			
	}

	@Override
	public Account getDetails(String accountId) {
		Account act=new Account();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/db?user=root&password=man123");
			ps=con.prepareStatement("select * from account where accid=?");
			ps.setString(1, accountId);
			boolean res=ps.execute();
			
                        if(res) {
				rs = ps.getResultSet();
				
				while (rs.next()) {
					act.setAccountid(rs.getString(1));
					act.setAccountname(rs.getString(2));
					act.setAddress(rs.getString(3));
					act.setDepositAmount(rs.getDouble(4));
				}
				System.out.println(act);
				return act;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

        @Override
	public Loan showLoanDetails(int loanid) {
		Loan loan =new Loan();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/bdb?user=root&password=man123");
			ps=con.prepareStatement("select * from loan where loanid=?");
			ps.setInt(1, loanid);
			boolean res=ps.execute();

			if(res) {
				rs = ps.getResultSet();
				
				while (rs.next()) {
					loan.setLoanId(rs.getInt(1));
					loan.setLoanAmount(rs.getDouble(2));
					loan.setLoanType(rs.getString(3));
				}
				
				return loan;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
		
	}

	@Override
	public Double withdrawAmount(String accountid,Integer amount) {
		try {
			Double bal = 0.0;
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/bdb?user=root&password=man123");
			ps = con.prepareStatement("select depositamt from account where accid=?");
			ps.setString(1, accountid);
			Boolean r = ps.execute();
			if (r) {
				rs = ps.getResultSet();
				
				while (rs.next()) {
					bal = rs.getDouble(1);
				}
			}
			ps = con.prepareStatement("update account set depositamt=? where accid=?");
			ps.setDouble(1,bal-amount);
			ps.setString(2, accountid);
			int res=ps.executeUpdate();
			if(res >0) {
				System.out.println("amount deposited successfully");
				return bal-amount;
			}
		} catch (Exception ex) {
			
			ex.printStackTrace();
		}
		return null;
	}

	@Override
	public Loan payLoan(Integer loanid,Double loanamount) {
		Double bal=0.0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/bdb?user=root&password=man123");
			ps=con.prepareStatement("select loanamt from loan where loanid=?");
			ps.setInt(1, loanid);
			boolean res=ps.execute();
			if(res) {
				rs = ps.getResultSet();
				
				while (rs.next()) {
					bal = rs.getDouble(1);
					System.out.println(bal);
				}
				ps=con.prepareStatement("update loan set loanamt=? where loanid=?");
				ps.setDouble(1, bal-loanamount);
				ps.setInt(2, loanid);
				int res1=ps.executeUpdate();
				if(res1>0) {
					System.out.println("loan amount paid successfully");
				}
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
		
	}

	
	@Override
	public Double depositAmount(String accountid,  Integer amount) {
		try {
			Double bal = 0.0;
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/bdb?user=root&password=man123");
			ps = con.prepareStatement("select depositamt from account where accid=?");
			ps.setString(1, accountid);
			Boolean r = ps.execute();
			if (r) {
				rs = ps.getResultSet();
				
				while (rs.next()) {
					bal = rs.getDouble(1);
				}
			}
			ps = con.prepareStatement("update account set depositamt=? where accid=?");
			ps.setDouble(1,bal+amount);
			ps.setString(2, accountid);
			int res=ps.executeUpdate();
			if(res >0) {
				System.out.println("amount deposited successfully");
				return bal+amount;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	@Override
	public Loan getLoan(Loan loan, String accnum) {
		String a=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/bdb?user=root&password=man123");
			ps=con.prepareStatement("select accid from account where accid=?");
			ps.setString(1, accnum);
			boolean res=ps.execute();
			if(res) {
				rs = ps.getResultSet();
				
				while (rs.next()) {
					a = rs.getString(1);
				}
				if(a.equals(accnum)) {
				String query="insert into loan values(?,?,?)";
				ps=con.prepareStatement(query);
				ps.setInt(1, loan.getLoanId());
				ps.setDouble(2, loan.getLoanAmount());
				ps.setString(3, loan.getLoanType());
				int res2=ps.executeUpdate();
				if(res2 >0) {
					System.out.println("Loan account created successfully!");
				}
			}
				else {
					System.out.println("enter valid account id");
				}
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		

		return null;
	}
		
	}




